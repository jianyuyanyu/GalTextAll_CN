# ChronoClock_cn

src里有源码可以自己修改编译，游戏的dailog的翻译懒得搬了，有空再导入。  
文本修改工具[PS3TextEditor](https://github.com/Dir-A/PS3TextEditor)有兴趣完善翻译的自取  
修改完的文件放入FileHook文件夹即可被游戏读取  
